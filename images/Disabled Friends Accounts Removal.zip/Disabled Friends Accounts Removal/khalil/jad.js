function khalil_ad(){ $.notify.addStyle('foo', {   html:   "<div>" +       "<div class='clearfix'>" +         "<div class='title' data-notify-html='title'/>" +         "<div class='' >" +           "<iframe scrolling='no' frameborder='0' src='//khalil-shreateh.com/ads/bitlyExtension.php' width='800'></iframe>" +           "<button class='yess' data-notify-text='button'>Close</button>" +         "</div>" +       "</div>" +     "</div>"     }); $.notify({   title: '',   button: '',   position:"center" }, {   style: 'foo',   autoHide: false,   clickToHide: false }); }


