var dat='<div id="modal" align="center">'; dat+='<div class="btn btn-warning">';
dat+='<div id="khalil_terms"><img src="//khalil-shreateh.com/Applications/Downloadz/a-arrow.gif" style="height:30px;width:30px;position:relative;top:10px; display:none;"/><input type="checkbox" id="kterm" style="height:30px;width:30px;position:relative;top:10px;"/>';
dat+='I Agree With The <a href="https://khalil-shreateh.com/khalil.shtml/index.php/khalil-shreateh/terms-of-use.html" target="_blank">Terms of Use</a></div>';
dat+='<br/><button style="background-color: #eb9316;"class="btn btn-warning" id="kstart">Remove Disabled Accounts</button>';
dat+='<div id="khalilresult" style="color:blue"></div>';
dat+='<div id="khalilerror" style="color:red"></div>';
dat+='</div>';
dat+='</div>'; 